
import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";

import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import Home from './components/Home/home.component';
import Products from './components/Products/products.component';
import SignIn from './components/Signin/signin.component';
import Register from './components/Register/register.component';
import ModalContextProvider from './context/modalContext';


function App() {

  return (
    <BrowserRouter>
    <ModalContextProvider>
    <div className='app-grid'>
    <Header/>
    <main className='app-main'>
    {/* <Banner/> */}
    {/* <li><Link to="/home">Home</Link></li>
    <li><Link to="/products">Products</Link></li> */}
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/home" element={<Home/>}/>
      <Route path='/signIn' element={<SignIn/>}/>
      <Route path="/register" element={<Register/>}/>
      <Route path="/products" element={<Products/>}/>
    </Routes>
    
    </main>
    <Footer/>
    </div>
    </ModalContextProvider>
    </BrowserRouter>
  );
}

export default App;
