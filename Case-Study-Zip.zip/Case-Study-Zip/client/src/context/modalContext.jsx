import React, {useState, Component} from "react";
export const ModalContext = React.createContext(false);


export default function ModalContextProvider(props) {

    const [opened,setOpened] = useState({opened:false});
    

    return (
        <ModalContext.Provider
        value={{
          opened: opened.opened,
          toggle: () => {
            setOpened({opened:!opened.opened});
          },
        }}
      >
        {props.children}
      </ModalContext.Provider> 
    )
}
