import React, { useEffect } from 'react';
import './card.component.scss';
import Button from '../Button/button.component';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { FetchProductsAsync, FilterProducts, UpdateEnableOfCategory } from '../../actions/actionCreators';

export default function Card(props) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(()=> {
    dispatch(FetchProductsAsync());
  },[]);

  console.log("props in card",props);
    let contentToRender = <div className={`card  card__${props.direction}`}>
            <div className="card__img">
                <img className="card__img--item" src={props.content.imageUrl} alt="Food Images"/>
            </div>
            <div className="card__text-content">
                <h2 className='card__heading-secondary'>{props.content.name}</h2>
                <h3 className='card__heading-tertiary'>{props.content.description}</h3>
                <Button content={`Explore ${props.content.key}`}
                Click={() => {
                  // dispatch(FilterProducts(props.content.id));
                  navigate('/products');
                  // if (props.content.enabled) {
                  //   dispatch(UpdateEnableOfCategory(props.content.id));
                  // } else {
                  //   // dispatch(UpdateEnableOfCategory(props.content.id));
                  //   dispatch(FetchProductsAsync());
                  // }

                }}/>
            </div>
        </div>;

  return ( 
    props.content.enabled && contentToRender
  )

}
