import React, { useContext } from 'react';

import './Header.scss';
import {Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { ModalContext } from '../../context/modalContext';
import Cart from '../Cart/cart.component';
import { cart } from '../../reducers/cart.reducer';





export default function Header() {

    const {cart} = useSelector((store) => store);
    const modelContext = useContext(ModalContext);
  return (
        <header className='header'>
            <div className='header__logo-box'>
                <Link to="/" className="header__logo-box--img" alt="logo image">
                <img src={process.env.PUBLIC_URL + '/static/images/logo.png'} />
                </Link>
                <nav className="header__logo-box__navigation">
                    <ul className="header__logo-box__list">
                        <li><Link className='header__logo-box--link' to="/home">Home</Link></li>
                        <li><Link className='header__logo-box--link' to="/products">Products</Link></li>
                    </ul>
                </nav>
            </div>
             <div className="header__cart-section">
                <nav className='header__cart-section--navigation'>
                    <ul className='header__cart-section--list'>
                        <div className="header__cart-section--signin-register">
                        <li><Link to="/signin" className="header__cart-section--link">Signin</Link></li>
                        <li><Link to="/register" className='header__cart-section--link'>Register</Link></li>
                        </div>
                        <div className='header__cart-section--cart'
                        onClick={() => modelContext.toggle()}>
                        <li>
                            <span>
                            <svg className="header__cart-section--cart__button" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z">
                            </path>
                            </svg>
                            </span>
                        </li>
                        <li><p>{cart.totalItems} items</p></li>
                        </div>
                        {modelContext.opened ? <Cart/> : null}
                    </ul>
                </nav>
            </div> 
            {/* <Button content="Explore fruit-and-veg"/> */}
        </header>
  )
}
