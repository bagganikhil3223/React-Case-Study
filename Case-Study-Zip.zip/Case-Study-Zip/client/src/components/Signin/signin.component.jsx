import React from "react";
import Button from "../Button/button.component";
import InputComponent from "../Inputs/input.component";
import "./signin.component.scss";

export default function SignIn() {
  let email = {
    placeholder:'Email',
    id:'email',
    type:'email',
  }

  let password = {
    placeholder:'Password',
    id:'password',
    type:'password'
  }

  return (
    <div className="login">
      <div className="login__headings">
        <h2 className="login__heading">Login</h2>
        <p className="login__primary-text">Get Access to your Orders, Wishlist and Recommendations.</p>
      </div>
      <div className="login__inputs">
      <InputComponent content={email}/>
      <InputComponent content={password}/>
      <Button type="submit" content={"Login"} width="width" />
      </div>
    </div>
  );
}
