import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {FetchProductsAsync, FilterProducts, UpdateEnableOfCategory } from '../../actions/actionCreators';
import './side-navigation.component.scss';

export default function SideNavigation(props) {

    const dispatch = useDispatch();

    const listToRender = props.categories.map(data => {
        return <li className={`side-nav__list--item ${!data.enabled ? 'active' : ''}`} key={data.id}><a key={data.id}
        onClick={() => {
            if (data.enabled) {
                console.log('Inside If');
                dispatch(UpdateEnableOfCategory(data.id));
                dispatch(FilterProducts(data.id));
              } else {
                console.log('Inside else');
                dispatch(UpdateEnableOfCategory(data.id));
                dispatch(FetchProductsAsync());
              }
    
        }}>{data.name}</a></li>
    });
  return (
    <div className='side-nav'>
       <nav>
           <ul className="side-nav__list">
               {listToRender}
           </ul>
       </nav>
    </div>
  )
}
