import React, {useState, useEffect} from 'react'
import {useSelector } from 'react-redux';
import ProductsListingCard from '../Products-Listing-Card/products-listing-card.component'

export default function ProductsListing(props) {


   // const {products} = useSelector(store => store);

    


    // useEffect(() => {
    //     dispatch(FetchProductsAsync());



    // //     fetch('http://localhost:5000/products').then(data => data.json()).then(result => {
    // //  console.log('inside products', result);
    // //  setCardData(result);
    // // }).catch(err => {
    // //   console.log(err);
    // // });
    
    // },[]);

    const productCard = props.products.filterProducts.map((data) => {
        return <ProductsListingCard  Key={data.sku} productsData={data}/>
    });
  return (
    <div className='products-listing'>
        <div className='products-listing__card'>
        {productCard}
        </div>
    </div>
  )
}
