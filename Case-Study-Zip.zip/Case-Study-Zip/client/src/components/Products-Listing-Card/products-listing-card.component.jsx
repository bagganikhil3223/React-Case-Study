import React from 'react';
import { useDispatch } from 'react-redux';
import { AddItemToCart} from '../../actions/actionCreators';
import Button from '../Button/button.component';
import './products-listing-card.component.scss';

export default function ProductsListingCard(props) {

    const dispatch = useDispatch();

    // function addItemsHandler(item) {
    //     // dispatch(addItemToCart(item));
    // }

    
  return (
    <div className='wrapper'>
    <div className='product-card'>
        <div className='product-card__heading'>
        <span>{props.productsData.name}</span>
        </div>
        <div className='product-card__image-box'>
        <img className='product-card__image' src={props.productsData.imageURL}/>
        </div>
        <div className='product-card__description-box'>
            {props.productsData.description}
        </div>
        <div className='product-card__price-box'>
            <p className='product-card__price-box--price'>MRP Rs. {props.productsData.price} </p>
            <Button content={"Buy Now"} Click={() => dispatch(AddItemToCart(props.productsData))}></Button>
        </div>
    </div>
    </div>
  )
}
