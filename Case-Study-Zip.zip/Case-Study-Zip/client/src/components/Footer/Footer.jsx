import React from 'react';
import './Footer.scss';

export default function Footer() {
  return (
    <footer className='footer'>
        <p className='footer__para'>Copyright &copy; 2011-2018 Sabka Bazaar Grocery Supplies Pvt. Ltd</p>
    </footer>
  )
}
