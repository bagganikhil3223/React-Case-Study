import React, { useEffect, useState } from 'react';
import './banner.component.scss';

export default function Banner() {
    const [bannerData, setBannerData] = useState([]);

    useEffect(() => {
        fetch('http://localhost:5000/banners').then(data => data.json()).then(result => {
     console.log('result is ', result);
     setBannerData([...result]);
    }).catch(err => {
      console.log(err);
    });
    },[]);

    const bannerToRender = bannerData.map(bannerData=> {
       return (
       <div className='banner'>
           <img className="banner__img" src={bannerData.bannerImageUrl}/>
       </div>
       );

    });

    console.log(bannerData);

  return (
    <div>
        {bannerData && (bannerToRender)}
    </div>
  )
}
