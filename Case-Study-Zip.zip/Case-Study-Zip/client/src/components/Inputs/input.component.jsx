import React from 'react';
import './input.component.scss';

export default function InputComponent(props) {
  return (
    <div className='form__box'>
        <form className="form">
        <div className="form__group">
          <input
            id={props.content.id}
            type={props.content.type}
            className="form__input"
            placeholder={props.content.placeholder}
            required
          />
          <label htmlFor={props.content.id} className="form__label">
              {props.content.placeholder}
          </label>
        </div>
      </form>
    </div>
  )
}
