import React from 'react';

import './carousel-item.component.scss';

export default function CarouselItem(props) {

    const { bannerImageUrl, bannerImageAlt } = props.banner;
    return (
      <div className={props.classappend}>
        <img
          src={process.env.PUBLIC_URL + bannerImageUrl}
          alt={bannerImageAlt}
        />
        ;
      </div>
    );
}
