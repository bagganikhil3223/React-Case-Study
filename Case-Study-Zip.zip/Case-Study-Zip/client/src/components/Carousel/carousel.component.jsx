import React,{useState} from 'react';
import CarouselItem from './carousel-item.component';

import './carousel.component.scss';

export default function Carousel(props) {
  // console.log(props.carouselData);
  const banners = props.carouselData;
  //const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [slideIndex, setSlideIndex] = useState(1);

  function nextSlide() {
    if (slideIndex !== banners.length) {
      setSlideIndex(slideIndex + 1);
    } else if (slideIndex === banners.length) {
      setSlideIndex(1);
    }
  }

  function prevSlide() {
    if (slideIndex !== 1) {
      setSlideIndex(slideIndex - 1);
    } else if (slideIndex === 1) {
      setSlideIndex(banners.length);
    }
  }
  const moveDot = (index) => {
    setSlideIndex(index);
  };
  return (
    <div className="container-slider">
      <button
        className="btn-slide prev"
        onClick={() => {
          prevSlide();
        }}
      >
        Pre
      </button>
      {banners.map((banner, index) => {
        return (
          <CarouselItem
            banner={banner}
            key={banner.id}
            classappend={`${
              slideIndex === index + 1 ? "slide active-anim" : "slide"
            }`}
          />
        );
      })}
      <button
        className="btn-slide next"
        onClick={() => {
          nextSlide();
        }}
      >
        Next
      </button>
      <div className="container-dots">
        {Array.from({ length: banners.length }).map((item, index) => (
          <div
            key={index}
            onClick={() => moveDot(index + 1)}
            className={slideIndex === index + 1 ? "dot active" : "dot"}
          ></div>
        ))}
      </div>
    </div>
  );
}

