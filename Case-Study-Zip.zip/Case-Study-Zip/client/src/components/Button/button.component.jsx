import React from 'react'
import './button.component.scss';
export default function Button(props) {
  return (
    <div className={`${props.width}`}>
        <a className="btn" onClick={props.Click}>{props.content}</a>
    </div>
  )
}
