import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FetchCategoriesAsync, FetchProductsAsync } from '../../actions/actionCreators';
import ProductsListing from '../Products-Listing/products-listing.component';
import SideNavigation from '../Side-Navigation/side-navigation.component';

import './products.component.scss';

export default function Products() {
  const dispatch = useDispatch();

  const {categories} = useSelector(store => store);

  const {products} = useSelector(store=> store);

  useEffect(()=> {
    dispatch(FetchProductsAsync());
  },[]);

  useEffect(()=> {
    dispatch(FetchCategoriesAsync());
},[]);
  return (
    <div className='products'>
      <SideNavigation categories={categories}/>
      <ProductsListing products={products}/>
    </div>
  )
}
