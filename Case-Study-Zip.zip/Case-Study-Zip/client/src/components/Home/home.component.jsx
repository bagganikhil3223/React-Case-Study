import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import Card from '../Card/card.component';
import Carousel from '../Carousel/carousel.component';


export default function Home() {

  const {categories} = useSelector(store => store);


    const [carouselData, setCarouselData] = useState([]);

    useEffect(() => {

      fetch('http://localhost:5000/banners').then(data => data.json()).then(result => {
       setCarouselData(result);
      }).catch(err => {
        console.log(err);
      });
    },[]);



    const cardData = categories.map((data,index) => {
        return <Card Key={data.key} content={data} direction={index % 2 == 0 ? 'image-left' : 'image-right'}/>
    })
  return (
      
    <div>
      <Carousel carouselData={carouselData}/>
       {cardData} 
    </div>
  )
}
