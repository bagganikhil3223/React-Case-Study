import React from 'react';
import Button from '../Button/button.component';
import InputComponent from '../Inputs/input.component';
import './register.component.scss';

export default function Register() {

  let firstName = {
    placeholder:'First Name',
    id:'firstName',
    type:'text'
  }

  let lastName= {
    placeholder:'Last Name',
    id:'LastName',
    type:'text'
  }

  let email = {
    placeholder:'Email',
    id:'email',
    type:'email',
  }

  let password = {
    placeholder:'Password',
    id:'password',
    type:'password'
  }

  let confirmPassword = {
    placeholder:'Confirm Password',
    id:'confirmPassword',
    type:'password'
  }

  return (
    <div className="signup">
      <div className="signup__headings">
        <h2 className="signup__heading">Signup</h2>
        <p className="signup__primary-text">We do not share your personal details with anyone.</p>
      </div>
      <div className="signup__inputs">
      <InputComponent content = {firstName}/>
      <InputComponent content={lastName}/>
      <InputComponent content={email}/>
      <InputComponent content={password}/>
      <InputComponent content={confirmPassword}/>
      <Button type="submit" content={"Signup"} width="width" />
      </div>
    </div>
  )
}
